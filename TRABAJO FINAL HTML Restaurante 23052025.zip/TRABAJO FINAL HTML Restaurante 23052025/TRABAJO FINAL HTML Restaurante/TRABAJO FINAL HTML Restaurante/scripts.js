document.addEventListener("DOMContentLoaded",function(){
    fetch("Header.html")
    .then(response=>response.text())
    .then(data=>document.getElementById("Header").innerHTML=data)

    fetch("Footer.html")
    .then(response=>response.text())
    .then(data=>document.getElementById("Footer").innerHTML=data)
    });
//Carga de Archivo.BodyCarta
document.addEventListener("DOMContentLoaded", function() {
    fetch("BodyCarta.html")
    .then(response => response.text())
    .then(data => {
        document.getElementById("BodyCarta").innerHTML = data;
    })
    .catch(error => console.error("Error al cargar BodyCarta.html:", error));
});
//--------------//
 document.addEventListener("DOMContentLoaded", () => {
  fetch("BodyReserva.html")
    .then(response => response.text())
    .then(html => {
      document.getElementById("BodyReserva").innerHTML = html;
    })
    .catch(error => {
      console.error("Error al cargar el formulario de reserva:", error);
    });
});
//---//
 document.getElementById('btnMostrarReserva').addEventListener('click', function() {
            fetch('BodyReserva.html') // Request the content of reserva-form.html
                .then(response => response.text()) // Get the response as text
                .then(html => {
                    document.getElementById('contenido-principal').innerHTML = html; // Insert the HTML into the div
                })
                .catch(error => {
                    console.error('Error al cargar el formulario de reserva:', error);
                    document.getElementById('contenido-principal').innerHTML = '<p class="text-danger">Hubo un error al cargar el formulario. Por favor, inténtelo de nuevo más tarde.</p>';
                });

});
